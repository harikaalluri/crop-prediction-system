package com.example.farmersspot;



import android.os.Bundle;
import android.app.Activity;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Register extends Activity implements OnClickListener{
	Button register;
	EditText EnterName,EnterAddress,EnterPassword,EnterPhonenum;
	SQLiteDatabase db;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
	super.onCreate(savedInstanceState);
	setContentView(R.layout.activity_register);
	EnterName=(EditText)findViewById(R.id.name); 
	EnterAddress=(EditText)findViewById(R.id.address);
	EnterPassword=(EditText)findViewById(R.id.password);
	EnterPhonenum=(EditText)findViewById(R.id.phonenum);
	register=(Button)findViewById(R.id.button1);
	register.setOnClickListener(this);
	db=openOrCreateDatabase("fardat", Context.MODE_PRIVATE, null);
		
		db.execSQL("CREATE TABLE IF NOT EXISTS fard(EnterName VARCHAR ,EnterPassword VARCHAR,EnterAddress VARCHAR, EnterPhonenum NUMBER);");
	}

	@Override
	public void onClick(View v) {
		if(EnterName.getText().toString().trim().length()==0||
				EnterPassword.getText().toString().trim().length()==0||EnterPhonenum.getText().toString().trim().length()==0||EnterAddress.getText().toString().trim().length()==0){
		
			Toast.makeText(Register.this, "please enter details", Toast.LENGTH_LONG).show();
		}
		else if(EnterPhonenum.getText().toString().length()!=10)
		{
			Toast.makeText(Register.this,"please enter 10 digits",Toast.LENGTH_LONG).show();
			}

		else{
			db.execSQL("INSERT INTO fard VALUES('"+EnterName.getText()+"','"+EnterPassword.getText()+"','"+EnterPhonenum.getText()+"','"+EnterAddress.getText()+"');");
			
			Toast.makeText(Register.this,"Registration is sucessfully completed",Toast.LENGTH_LONG).show();
			clearText();
		
			
		}

	}
			
		
		    public void clearText()
		    {
		    	EnterName.setText("");
		    	EnterPassword.setText("");
		    	EnterPhonenum.setText("");
		    	EnterAddress.setText("");
		    	

		    }
	}

