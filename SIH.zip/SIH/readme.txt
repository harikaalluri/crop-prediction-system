Crop Guidance and Farmers Friend
Problem Title : Helping the farmers in terms of Crop suggestion, precautions based on the met department forecast of rain fall / weather, potential pest attacks , weather warnings etc.

Problem statement:Helping farmers to take a decision to grow a particular crop and help them to maximize their profits and to increase crop production using Machine learning

Explanation: Our main motive is to focus on public-class issues, specifically on agriculture. Keeping in mind various factors like rainfall, humidity,temperature,moisture content, soil we suggest which type of crop can be suitable for that area. Not limiting to this we also recommend pesticides, various methods to improve crop yield depending on the atmosphere of the area. This project will be helpful to avoid the loss that crops bring due to inadequate information, and it focuses on better yeilding of crop.

Solution: We predict the crop that can grow in area based on rainfall, humidity,temperature,moisture content,soil using machine learning algorithms. Our system also suggest the pesticides and tips for farming based on the crop predicted.

Advantage: 1.Decreases the loss incured by farmers. 2.Increases the crop production, thus increases the economy of the country. 3.Decreases the cost of food and other items bringing stability in prices.