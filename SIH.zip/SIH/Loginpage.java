package com.example.farmersspot;





import android.os.AsyncTask;
import android.os.Bundle;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Loginpage extends Activity {

	
	EditText username, password;
	Button sub;
	String u;
    String p;
	SQLiteDatabase db;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		final GlobalClass globalvariabel = (GlobalClass)getApplicationContext();
		setContentView(R.layout.activity_loginpage);
		username = (EditText) findViewById(R.id.editText1);
		password = (EditText) findViewById(R.id.editText2);
		sub=(Button) findViewById(R.id.button1);
		sub.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub			
				if(username.getText().toString().equals("")||password.getText().toString().equals("")){
					
					Toast.makeText(Loginpage.this, "Please enter all the fields..!", Toast.LENGTH_LONG).show();
				}else{	 
					 u = username.getText().toString();
					 p = password.getText().toString();
					 
					          db=openOrCreateDatabase("fardat",SQLiteDatabase.CREATE_IF_NECESSARY,null);					    
					        }
					        	 
					        	
					        	 if(username.getText().toString().equals("admin")&& password.getText().toString().equals("admin")){
					        		 Toast.makeText(Loginpage.this, "Welcome To Admin Home Page "  + u , Toast.LENGTH_LONG).show();
					        			globalvariabel.Setusername(username.getText().toString().trim());
					        			Intent a = new Intent(Loginpage.this,FarmerHomepage.class);
					            		startActivity(a);
					            		clear();
					            		return;
									}
					        	 Cursor cc = db.rawQuery("select * from fard where EnterName= '"+u+"' and EnterPassword= '"+p+"' ", null); 
					        	 if(cc.moveToFirst())
					        		 {String temp="";					       
						            if (cc != null) {
						            	if(cc.getCount() > 0)
						            	{
						            	//return true;
						            scan g=new scan();
						            g.execute();
						            
						            		Toast.makeText(Loginpage.this, "Welcome To Farmerhomepage "  + u , Toast.LENGTH_LONG).show();
						            		globalvariabel.Setusername(username.getText().toString().trim());
						            		Intent b = new Intent(Loginpage.this,FarmerHomepage.class);
						            		startActivity(b);
						            		clear();
						            		return;
						            	}else{
						            		 Toast.makeText(Loginpage.this, "Login Failed...!", Toast.LENGTH_LONG).show();
						            		 clear();
						            	}
						            	}
					        		 }
					              
					              //lo
					        	 
					            else{
				            		 Toast.makeText(Loginpage.this, "Login Failed...!", Toast.LENGTH_LONG).show();
				            		 clear();
					        	 }
					        }//	
					      
						 	
					    
		});
		
	
		}		
		
			
	public class scan extends AsyncTask<String, String, String>{

		private ProgressDialog pd;

		protected void onPreExecute() {
			super.onPreExecute();
		 pd = new ProgressDialog(Loginpage.this);
		 pd.setTitle("Please Wait!!");
		 pd.setMessage("Logging you In....");
		 pd.setMax(10);
		 pd.show();
		}
	
		@Override
		protected String doInBackground(String... params) {
			// TODO Auto-generated method stub
			return null;
		}
	}	
	
	public void clear()
	{
		username.setText("");
		password.setText("");
	}
	
}
