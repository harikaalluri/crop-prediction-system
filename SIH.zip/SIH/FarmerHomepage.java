package com.example.farmersspot;




import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.Intent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class FarmerHomepage extends Activity {
	Button z;
	EditText hum,soil,moi,tem,rain;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_farmer_homepage);
		final GlobalClass globalvariabel = (GlobalClass)getApplicationContext();
		hum=(EditText)findViewById(R.id.editText1);
		soil=(EditText)findViewById(R.id.editText2);
		moi=(EditText)findViewById(R.id.editText3);
		tem=(EditText)findViewById(R.id.editText4);
		rain=(EditText)findViewById(R.id.editText5);
		z=(Button)findViewById(R.id.button1);
		z.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				
				
				showMessage("Recommended Crop", "Mangoes");}
		});
	}
	public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.farmer_homepage, menu);
		return true;
	}

}
