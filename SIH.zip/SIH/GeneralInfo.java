package com.example.farmersspot;


import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class GeneralInfo extends Activity implements OnClickListener{
	Button sub;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_general_info);
		sub=(Button)findViewById(R.id.button1);
		sub.setOnClickListener(this);
		sub=(Button)findViewById(R.id.button1);
		sub.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				showMessage("tips for cotton and price", "phorate,endosulfan,aldicarb\nPrice of cotton per quintal is 5900");}
		});

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.general_info, menu);
		return true;
	}

	
	public void showMessage(String title,String message)
    {
    	Builder builder=new Builder(this);
    	builder.setCancelable(true);
    	builder.setTitle(title);
    	builder.setMessage(message);
    	builder.show();
	}

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	}

}
